
// This is the content script for the extension.
// It runs in the context of YouTube pages and interacts with the DOM.

// Global variable to store cached study keywords
let cachedStudyKeywords = [];
// Local copy of entertainment keywords for content script's direct use
const ENTERTAINMENT_KEYWORDS_LOCAL = [
    'vlog', 'gaming', 'music video', 'funny', 'entertainment', 'comedy',
    'movie', 'series', 'trailer', 'prank', 'challenge', 'reaction',
    'stream', 'livestream', 'gameplay', 'highlights', 'fail', 'compilation',
    'song', 'music', 'official video', 'lyrics', 'remix', 'concert', 'live',
    'dance', 'album', 'track', 'audio', 'sound', 'beats', 'playlist', 'karaoke',
    'cover', 'mashup', 'performance', 'show', 'clip', 'short film', 'drama',
    'movie scene', 'cartoon', 'anime', 'tv series', 'episode', 'netflix', 'hbo',
    'disney', 'marvel', 'dc comics', 'celebrity', 'interview', 'talk show',
    'party', 'celebration', 'holiday', 'vacation', 'trip', 'journey', 'travelogue',
    'sports highlights', 'game highlights', 'funny moments', 'best moments', 'epic fails'
];

// Debounce utility function
function debounce(func, delay) {
    let timeout;
    return function(...args) {
        const context = this;
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(context, args), delay);
    };
}

// Function to hide YouTube Shorts elements
const debouncedHideShortsElements = debounce(() => {
    // Selectors for Shorts elements on the homepage, sidebar, and search results
    const shortsSelectors = [
        'ytd-rich-grid-renderer #contents .ytd-rich-item-renderer:has(ytd-reel-shelf-renderer)', // Home page shorts shelf
        'ytd-guide-entry-renderer:has(a[href="/shorts"])', // Sidebar Shorts link
        'ytd-thumbnail[href*="/shorts/"]', // Thumbnails linking to shorts
        'ytd-video-renderer:has(a[href*="/shorts/"])', // Search results shorts
        'ytd-compact-video-renderer:has(a[href*="/shorts/"])', // Compact shorts in sidebar
        'ytd-reel-shelf-renderer', // The entire shorts shelf component
        'a[href*="/shorts/"]' // Any link directly to shorts
    ];

    shortsSelectors.forEach(selector => {
        document.querySelectorAll(selector).forEach(element => {
            if (element) {
                element.style.display = 'none'; // Hide the element
                // console.log('Hidden Shorts element:', element);
            }
        });
    });

    // The service worker handles redirects for /shorts/ URLs using onBeforeNavigate.
    // We remove the window.location.href redirect from here to prevent throttling.
}, 200); // Debounce by 200ms


/**
 * Function to be injected and executed in the content script context
 * to show a well-done message.
 */
function showWellDoneMessage() {
    // Remove any existing well-done messages to prevent duplicates
    const existingMessage = document.getElementById('studyzone-well-done-message');
    if (existingMessage) {
        existingMessage.remove();
    }

    const messageDiv = document.createElement('div');
    messageDiv.id = 'studyzone-well-done-message';
    messageDiv.textContent = 'Well done! You\'re in the StudyZone.';
    messageDiv.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background-color: #4CAF50; /* Green */
        color: white;
        padding: 12px 25px;
        border-radius: 8px;
        font-family: 'Inter', sans-serif;
        font-size: 1.1rem;
        font-weight: 600;
        z-index: 100000;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        opacity: 0;
        transition: opacity 0.5s ease-in-out;
    `;

    document.body.appendChild(messageDiv);

    // Fade in
    setTimeout(() => {
        messageDiv.style.opacity = '1';
    }, 100);

    // Fade out and remove after a few seconds
    setTimeout(() => {
        messageDiv.style.opacity = '0';
        setTimeout(() => {
            messageDiv.remove();
        }, 500); // Wait for transition to finish before removing
    }, 4000); // Display for 4 seconds
}

/**
 * Function to be injected and executed in the content script context
 * to show the warning modal.
 * This function must be self-contained and not rely on external variables
 * from the service worker's scope.
 * @param {string} savedKeywords - Comma-separated string of user's study keywords.
 */
function showWarningModal(savedKeywords) {
    // Check if the modal already exists to prevent multiple modals
    if (document.getElementById('studyzone-warning-modal')) {
        return;
    }

    // Create modal container
    const modal = document.createElement('div');
    modal.id = 'studyzone-warning-modal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.7);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 99999;
        font-family: 'Inter', sans-serif;
    `;

    // Create modal content box
    const modalContent = document.createElement('div');
    modalContent.style.cssText = `
        background-color: #fff;
        padding: 2.5rem; /* Increased padding */
        border-radius: 12px; /* Slightly more rounded */
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.4); /* Stronger shadow */
        text-align: center;
        max-width: 450px; /* Slightly wider */
        width: 90%;
        color: #333;
        position: relative;
    `;

    // Create title
    const title = document.createElement('h2');
    title.textContent = 'Hold On!';
    title.style.cssText = `
        font-size: 2.2rem; /* Increased font size */
        font-weight: bold;
        margin-bottom: 1.2rem;
        color: #ef4444; /* Red color */
    `;

    // Create message
    const message = document.createElement('p');
    message.textContent = 'This video appears to be entertainment content. Are you sure you want to proceed? Remember your study goals!';
    message.style.cssText = `
        font-size: 1.1rem; /* Increased font size */
        margin-bottom: 1.8rem;
        line-height: 1.6;
    `;

    // Create keywords display
    const keywordsDisplay = document.createElement('p');
    keywordsDisplay.innerHTML = `**Your Focus Topics:** <span style="font-weight: 600; color: #3b82f6;">${savedKeywords || 'None set'}</span>`;
    keywordsDisplay.style.cssText = `
        font-size: 0.95rem;
        margin-bottom: 2rem;
        color: #555;
    `;


    // Create button container
    const buttonContainer = document.createElement('div');
    buttonContainer.style.cssText = `
        display: flex;
        justify-content: space-around;
        gap: 1.2rem; /* Increased gap */
    `;

    // Create "Go Back" button
    const goBackButton = document.createElement('button');
    goBackButton.textContent = 'Go Back to Study';
    goBackButton.style.cssText = `
        background-color: #3b82f6; /* Blue */
        color: white;
        padding: 0.85rem 1.5rem; /* Increased padding */
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 1.05rem; /* Slightly larger font */
        font-weight: 600;
        transition: background-color 0.2s ease, transform 0.2s ease;
        flex: 1;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    `;
    goBackButton.onmouseover = () => goBackButton.style.backgroundColor = '#2563eb';
    goBackButton.onmouseout = () => goBackButton.style.backgroundColor = '#3b82f6';
    goBackButton.onclick = () => {
        // Attempt to pause the video
        const videoPlayer = document.querySelector('video');
        if (videoPlayer) {
            videoPlayer.pause();
            console.log('Video paused.');
        }
        // Redirect to YouTube homepage
        window.location.href = 'https://www.youtube.com/';
        modal.remove(); // Remove the modal
    };

    // Create "Proceed Anyway" button
    const proceedButton = document.createElement('button');
    proceedButton.textContent = 'Proceed Anyway';
    proceedButton.style.cssText = `
        background-color: #6b7280; /* Gray */
        color: white;
        padding: 0.85rem 1.5rem; /* Increased padding */
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 1.05rem; /* Slightly larger font */
        font-weight: 600;
        transition: background-color 0.2s ease, transform 0.2s ease;
        flex: 1;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    `;
    proceedButton.onmouseover = () => proceedButton.style.backgroundColor = '#4b5563';
    proceedButton.onmouseout = () => proceedButton.style.backgroundColor = '#6b7280';
    proceedButton.onclick = () => {
        modal.remove(); // Just remove the modal
    };

    // Append elements
    modalContent.appendChild(title);
    modalContent.appendChild(message);
    modalContent.appendChild(keywordsDisplay); // Add keywords display
    modalContent.appendChild(buttonContainer);
    buttonContainer.appendChild(goBackButton);
    buttonContainer.appendChild(proceedButton);
    modal.appendChild(modalContent);

    // Append modal to the body
    document.body.appendChild(modal);
}


// Function to analyze video content
async function analyzeCurrentVideo() {
    // Only analyze if it's a video watch page
    if (window.location.pathname.startsWith('/watch')) {
        const videoTitleElement = document.querySelector('h1.ytd-watch-metadata yt-formatted-string');
        const videoDescriptionElement = document.querySelector('#description .yt-formatted-string');

        const videoTitle = videoTitleElement ? videoTitleElement.textContent : '';
        const videoDescription = videoDescriptionElement ? videoDescriptionElement.textContent : '';

        // If title or description are not immediately available, retry after a short delay
        if (!videoTitle && !videoDescription) {
            console.log('Video title/description not yet available, retrying analysis...');
            setTimeout(analyzeCurrentVideo, 200); // Retry after 200ms
            return;
        }

        if (videoTitle || videoDescription) {
            // Use cached study keywords
            const currentStudyKeywords = cachedStudyKeywords;

            // Convert to lowercase for case-insensitive matching
            const lowerTitle = videoTitle ? videoTitle.toLowerCase() : '';
            const lowerDescription = videoDescription ? videoDescription.toLowerCase() : '';

            // Check if video contains any study keywords
            const isStudyRelated = currentStudyKeywords.some(keyword =>
                lowerTitle.includes(keyword.toLowerCase()) || lowerDescription.includes(keyword.toLowerCase())
            );

            // Check if video contains any entertainment keywords
            let isEntertainment = ENTERTAINMENT_KEYWORDS_LOCAL.some(keyword =>
                lowerTitle.includes(keyword.toLowerCase()) || lowerDescription.includes(keyword.toLowerCase())
            );

            console.log(`Video Title: "${videoTitle}"`);
            console.log(`Is Study Related: ${isStudyRelated}`);
            console.log(`Is Entertainment: ${isEntertainment}`);

            // Logic:
            // 1. If it's study-related AND NOT entertainment, show well-done.
            // 2. If it's entertainment AND NOT study-related, show warning.
            // 3. Otherwise (mixed content, or neither), do nothing.

            if (isStudyRelated && !isEntertainment) {
                console.log('Triggering well-done message directly from content script.');
                showWellDoneMessage(); // Call directly
            } else if (isEntertainment && !isStudyRelated) {
                console.log('Triggering entertainment warning directly from content script.');
                showWarningModal(currentStudyKeywords.join(', ')); // Call directly
            }
        }
    }
}

// Function to initialize cached keywords
async function initializeCachedKeywords() {
    const result = await chrome.storage.sync.get(['studyKeywords']);
    cachedStudyKeywords = result.studyKeywords || [];
    console.log('Cached Study Keywords initialized:', cachedStudyKeywords);
}

// Listen for changes in storage to update cached keywords
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'sync' && changes.studyKeywords) {
        cachedStudyKeywords = changes.studyKeywords.newValue || [];
        console.log('Cached Study Keywords updated:', cachedStudyKeywords);
    }
});


// Use a MutationObserver to dynamically hide Shorts elements as they load
// Target a more specific element like 'ytd-app' or '#page-manager'
const targetNode = document.querySelector('ytd-app') || document.body; // Fallback to body if ytd-app not found

const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
        if (mutation.addedNodes.length > 0) {
            debouncedHideShortsElements(); // Call debounced version
        }
    });
});

// Start observing the target node for changes
if (targetNode) {
    observer.observe(targetNode, { childList: true, subtree: true });
    console.log('MutationObserver started on:', targetNode.id || 'body');
} else {
    console.warn('Could not find ytd-app, observing body. Performance might be affected.');
}


// Initial call to hide existing shorts elements on page load
debouncedHideShortsElements(); // Call debounced version

// Listen for URL changes (e.g., when navigating between videos without a full page reload)
// This is important for single-page applications like YouTube.
let lastUrl = location.href;
new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    console.log('URL changed to:', url);
    // When URL changes, re-analyze video content
    // Give YouTube a moment to update the DOM with new video details
    debouncedAnalyzeCurrentVideo(); // Call debounced version
  }
}).observe(document, { subtree: true, childList: true });

// Initial setup: Initialize keywords and then trigger the debounced analysis
initializeCachedKeywords(); // Initialize keywords on script load
// Define debouncedAnalyzeCurrentVideo here, *before* its initial call
const debouncedAnalyzeCurrentVideo = debounce(analyzeCurrentVideo, 500); // Debounce by 500ms
debouncedAnalyzeCurrentVideo(); // Call debounced version immediately on script load

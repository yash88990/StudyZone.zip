
// This is the background script (service worker) for the extension.
// It runs in the background and handles events, communication, and persistent logic.

// Default entertainment keywords (can be expanded)
const ENTERTAINMENT_KEYWORDS = [
    'vlog', 'gaming', 'music video', 'funny', 'entertainment', 'comedy',
    'movie', 'series', 'trailer', 'prank', 'challenge', 'reaction',
    'stream', 'livestream', 'gameplay', 'highlights', 'fail', 'compilation',
    'song', 'music', 'official video', 'lyrics', 'remix', 'concert', 'live',
    'dance', 'album', 'track', 'audio', 'sound', 'beats', 'playlist', 'karaoke',
    'cover', 'mashup', 'performance', 'show', 'clip', 'short film', 'drama',
    'movie scene', 'cartoon', 'anime', 'tv series', 'episode', 'netflix', 'hbo',
    'disney', 'marvel', 'dc comics', 'celebrity', 'interview', 'talk show',
    'party', 'celebration', 'holiday', 'vacation', 'trip', 'journey', 'travelogue',
    'sports highlights', 'game highlights', 'funny moments', 'best moments', 'epic fails'
];

// Listen for when the extension is installed or updated
chrome.runtime.onInstalled.addListener(() => {
    console.log('StudyZone extension installed.');
    // Initialize default settings if not already present
    chrome.storage.sync.get(['studyKeywords'], (result) => {
        if (!result.studyKeywords) {
            chrome.storage.sync.set({ studyKeywords: [] });
        }
    });
});

// Listen for navigation events to YouTube pages
chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
    // Only act on main frame navigations to YouTube
    if (details.frameId === 0 && details.url.includes('youtube.com')) {
        // Check for YouTube Shorts URL
        if (details.url.includes('/shorts/')) {
            console.log('Blocking YouTube Shorts (onBeforeNavigate):', details.url);
            chrome.tabs.update(details.tabId, { url: 'https://www.youtube.com/' });
            return; // Stop further processing for Shorts
        }

        // If it's a regular YouTube video page, send a message to the content script
        // to analyze the video title and description.
        if (details.url.includes('v=')) {
            console.log('Navigating to YouTube video. Content script will analyze.');
        }
    }
});
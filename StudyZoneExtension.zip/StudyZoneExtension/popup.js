
document.addEventListener('DOMContentLoaded', function() {
    const studyKeywordsInput = document.getElementById('studyKeywords');
    const saveSettingsBtn = document.getElementById('saveSettingsBtn');
    const statusMessage = document.getElementById('statusMessage');

    // Load saved settings when the popup opens
    chrome.storage.sync.get(['studyKeywords'], function(result) {
        if (result.studyKeywords) {
            studyKeywordsInput.value = result.studyKeywords.join(', ');
        }
    });

    // Save settings when the button is clicked
    saveSettingsBtn.addEventListener('click', function() {
        const keywords = studyKeywordsInput.value.split(',').map(kw => kw.trim()).filter(kw => kw !== '');
        chrome.storage.sync.set({ studyKeywords: keywords }, function() {
            statusMessage.textContent = 'Settings saved!';
            statusMessage.classList.remove('hidden');
            setTimeout(() => {
                statusMessage.classList.add('hidden');
            }, 2000); // Hide message after 2 seconds
        });
    });
});

